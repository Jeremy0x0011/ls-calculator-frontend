# Frontend Code Style

- Use two spaces for JavaScript, Vue, JSON, and CSS indentation.
- Use single quotes in JavaScript and semicolons only when needed by the project style.
- Keep API request functions in `src/api.js`; do not calculate results in Vue components.
- Use Vue Composition API refs for local component state.
- Show request failures to the user instead of presenting an empty success state.
- Keep controls keyboard accessible and give icon-only buttons accessible labels.
